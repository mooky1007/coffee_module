class DoughnutChart {
    constructor(className, config = {}) {
        this.container = document.querySelector(className);
        const chart = this.container.querySelector('DoughnutChart');
        this.data = [...chart.querySelectorAll('ChartItem')].map((el) => {
            return {
                name: el.dataset.name,
                value: el.dataset.value,
                color: el.dataset.color,
                textColor: el.dataset.textcolor,
                replaceText: el.dataset.replacetext,
            };
        });
        this.duration = config.duration || 3000;

        this.config = config;
        window.addEventListener('resize', this.onResize.bind(this));

        this.init();
    }

    init() {
        this.container.innerHTML = '';
        const canvas = document.createElement('canvas');
        this.container.append(canvas);
        const dpr = 2;

        const { width, height } = this.container.getBoundingClientRect();

        canvas.width = width * dpr;
        canvas.height = height * dpr;

        canvas.style.width = `${width}px`;
        canvas.style.height = `${height}px`;

        this.width = width;
        this.height = height;

        const ctx = canvas.getContext('2d');
        ctx.scale(dpr, dpr);
        this.ctx = ctx;

        ctx.save();
        ctx.strokeStyle = 'rgba(255, 255, 255 ,0.1)';
        this.drawEmpty();
    }

    drawEmpty() {
        const { ctx, width, height } = this;
        ctx.save();
        ctx.lineWidth = width * this.config.lineWidthRatio;
        const chartCenter = [width / 2, height / 2];
        const chartWidth = (width * this.config.chartWidthRatio - ctx.lineWidth) / 2;

        ctx.beginPath();
        ctx.arc(...chartCenter, chartWidth, 0, Math.PI * 2);
        ctx.stroke();
        ctx.closePath();
        ctx.restore();
    }

    render(currentTime) {
        const reqId = requestAnimationFrame(this.render.bind(this));

        if (!this.startTime) this.startTime = currentTime;
        const elapsed = currentTime - this.startTime;

        const progress = easeInOutSine(Math.min(elapsed / this.duration, 1));
        if (progress >= 1) cancelAnimationFrame(reqId);

        const { ctx, width, height } = this;
        ctx.clearRect(0, 0, width, height);

        ctx.lineWidth = width * this.config.lineWidthRatio;
        const chartCenter = [width / 2, height / 2];
        const chartWidth = (width * this.config.chartWidthRatio - ctx.lineWidth) / 2;

        this.drawEmpty();

        this.data.reduce((acc, cur) => {
            const chartStart = (acc * Math.PI) / 180;
            const chartEnd = chartStart + ((cur.value * 3.6 * Math.PI) / 180) * progress;

            ctx.save();
            ctx.strokeStyle = cur.color;
            ctx.beginPath();
            ctx.arc(...chartCenter, chartWidth, chartStart, chartEnd);
            ctx.stroke();
            ctx.closePath();
            ctx.restore();

            const middleAngle = (chartStart + chartEnd) / 2;

            const textRadius = chartWidth;
            const textX = chartCenter[0] + Math.cos(middleAngle) * textRadius;
            const textY = chartCenter[1] + Math.sin(middleAngle) * textRadius;

            ctx.save();
            ctx.fillStyle = cur.textColor;
            ctx.font = `${width * this.config.fontSizeRatio}px ${(this.config.fontFamily || []).map((ff) => `"${ff}"`).join(', ')}, sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(`${cur.replaceText ? cur.replaceText : `${cur.value}%`}`, textX, textY);
            ctx.restore();

            return (chartEnd / Math.PI) * 180;
        }, -90);
    }

    onResize() {
        this.init();
        this.render(performance.now());
    }

    play() {
        this.startTime = null;
        requestAnimationFrame(this.render.bind(this));
    }
}

function easeInOutSine(x) {
    return -(Math.cos(Math.PI * x) - 1) / 2;
}
